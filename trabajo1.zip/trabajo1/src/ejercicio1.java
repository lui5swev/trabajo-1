public class ejercicio1 {
    public static void main(String[] args) {
        String x = "Hola";
        invertirString(x);
        int[] numeros = {1, 4, 6, 8, 9, 11, 18};
        numerosPares(numeros);
    }

    public static void invertirString(String palabra){
        String invertida = "";
        for (int i = palabra.length() - 1; i >=0 ; i--){
            invertida += palabra.charAt(i);
        }
        System.out.println(palabra);
        System.out.println(invertida);

    }

    public static void numerosPares(int[] array){
        int sumaPares = 0;
        for (int i = 0; i < array.length; i++) {
            if(array[i]%2==0){
                sumaPares += array[i];
            }
        }
        System.out.println("la suma de los numeros pares del arreglo es: "+sumaPares);
    }

}