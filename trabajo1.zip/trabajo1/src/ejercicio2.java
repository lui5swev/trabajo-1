public class ejercicio2 {
    public static void main(String[] args) {
        double[] notas = {4.0, 3.6, 2.0, 4.0};
        double sumaNotas = sumarNotas(notas);

        mostrarResultado(calcularPromedio(notas,sumaNotas));
    }

    private static void mostrarResultado(double promedio) {
        System.out.println("Tu promedio es: "+promedio);
        if(promedio>=4.0){
            System.out.println("Aprobaste");
        } else if (promedio<3.6) {
            System.out.println("Reprobaste");
        }else{
            System.out.println("Vas a examen");
        }
    }

    private static double sumarNotas(double[] a) {
        double suma = 0;
        for (int i = 0; i < a.length; i++) {
            suma += a[i];
        }
        return suma;
    }

    private static double calcularPromedio(double[] x,double y) {
        int numNotas = x.length;
        double sumaNotas = y;
        var promedio = sumaNotas/numNotas;

        return promedio;
    }
}